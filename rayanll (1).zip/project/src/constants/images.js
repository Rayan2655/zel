export const IMAGES = {
  LOGO: 'https://raw.githubusercontent.com/rayanpharmacy/assets/main/logo.png',
  ALLERGY_RELIEF: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?auto=format&fit=crop&q=80&w=200&h=200'
};