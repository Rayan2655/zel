export const ROUTES = {
  HOME: '#',
  CATEGORIES: '#categories',
  PRESCRIPTIONS: '#prescriptions',
  CONTACT: '#contact'
};