export const coffees = [
  {
    id: 1,
    name: 'Perspicatis',
    image: 'https://via.placeholder.com/200'
  },
  {
    id: 2,
    name: 'Voluptatem',
    image: 'https://via.placeholder.com/200'
  },
  {
    id: 3,
    name: 'Explicabo',
    image: 'https://via.placeholder.com/200'
  },
  {
    id: 4,
    name: 'Rhichetto',
    image: 'https://via.placeholder.com/200'
  },
  {
    id: 5,
    name: 'Beatae',
    image: 'https://via.placeholder.com/200'
  },
  {
    id: 6,
    name: 'Vitze',
    image: 'https://via.placeholder.com/200'
  }
];