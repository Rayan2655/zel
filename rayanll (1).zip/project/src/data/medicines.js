import { IMAGES } from '../constants/images.js';

export const medicines = [
  {
    id: 1,
    name: 'Pain Relief',
    description: 'Effective pain management medications',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&q=80&w=200&h=200',
    category: 'Over-the-counter'
  },
  {
    id: 2,
    name: 'Antibiotics',
    description: 'Prescription antibiotics (Requires prescription)',
    image: 'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?auto=format&fit=crop&q=80&w=200&h=200',
    category: 'Prescription'
  },
  {
    id: 3,
    name: 'Vitamins',
    description: 'Daily essential vitamins and supplements',
    image: 'https://images.unsplash.com/photo-1512069772995-ec65ed45afd6?auto=format&fit=crop&q=80&w=200&h=200',
    category: 'Supplements'
  },
  {
    id: 4,
    name: 'First Aid',
    description: 'Essential first aid supplies',
    image: 'https://images.unsplash.com/photo-1631549916768-4119b2e5f926?auto=format&fit=crop&q=80&w=200&h=200',
    category: 'Medical Supplies'
  },
  {
    id: 5,
    name: 'Allergy Relief',
    description: 'Antihistamines and allergy medications',
    image: IMAGES.ALLERGY_RELIEF,
    category: 'Over-the-counter'
  },
  {
    id: 6,
    name: 'Diabetes Care',
    description: 'Diabetes management supplies',
    image: 'https://images.unsplash.com/photo-1579165466741-7f35e4755660?auto=format&fit=crop&q=80&w=200&h=200',
    category: 'Medical Supplies'
  }
];