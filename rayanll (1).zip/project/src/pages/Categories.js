export function Categories() {
  return `
    <div class="page categories-page">
      <div class="container">
        <h1>Medicine Categories</h1>
        <div class="categories-grid">
          <div class="category-card">
            <i class="category-icon pain-relief"></i>
            <h3>Pain Relief</h3>
          </div>
          <div class="category-card">
            <i class="category-icon antibiotics"></i>
            <h3>Antibiotics</h3>
          </div>
          <!-- Add more categories -->
        </div>
      </div>
    </div>
  `;
}