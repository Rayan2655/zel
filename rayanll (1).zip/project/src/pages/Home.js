export function Home() {
  return `
    <div class="page home-page">
      <section class="hero">
        <h1>Welcome to Rayan Pharmacy</h1>
        <p>Your trusted healthcare partner</p>
      </section>
      <section class="featured-products container">
        <h2>Featured Products</h2>
        <div class="products-grid"></div>
      </section>
    </div>
  `;
}