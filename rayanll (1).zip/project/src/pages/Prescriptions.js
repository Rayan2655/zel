export function Prescriptions() {
  return `
    <div class="page prescriptions-page">
      <div class="container">
        <h1>Prescription Services</h1>
        <div class="prescription-form">
          <form class="upload-form">
            <h3>Upload Prescription</h3>
            <div class="form-group">
              <label>Upload your prescription</label>
              <input type="file" accept="image/*,.pdf" />
            </div>
            <button type="submit" class="btn-primary">Submit Prescription</button>
          </form>
        </div>
      </div>
    </div>
  `;
}