export function Contact() {
  return `
    <div class="page contact-page">
      <div class="container">
        <h1>Contact Us</h1>
        <div class="contact-grid">
          <div class="contact-form">
            <form>
              <div class="form-group">
                <label>Name</label>
                <input type="text" placeholder="Your name" />
              </div>
              <div class="form-group">
                <label>Email</label>
                <input type="email" placeholder="Your email" />
              </div>
              <div class="form-group">
                <label>Message</label>
                <textarea placeholder="Your message"></textarea>
              </div>
              <button type="submit" class="btn-primary">Send Message</button>
            </form>
          </div>
          <div class="contact-info">
            <h3>Get in Touch</h3>
            <p>Email: contact@rayanpharmacy.com</p>
            <p>Phone: (555) 123-4567</p>
            <p>Address: 123 Health Street, Medical District</p>
          </div>
        </div>
      </div>
    </div>
  `;
}