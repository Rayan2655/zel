export function handleMedicineTaste(medicineName) {
  alert(`Thank you for tasting ${medicineName}! Our pharmacist will assist you shortly.`);
}