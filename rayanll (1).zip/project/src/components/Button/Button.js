export function Button({ text, onClick, className = '' }) {
  return `
    <button 
      class="action-button ${className}"
      onclick="${onClick}"
    >
      ${text}
    </button>
  `;
}