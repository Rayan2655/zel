import { IMAGES } from '../../constants/images.js';

export function Logo() {
  return `
    <div class="logo">
      <img src="${IMAGES.LOGO}" alt="Rayan Pharmacy Logo" class="logo-image">
      <h1>Rayan Pharmacy</h1>
    </div>
  `;
}