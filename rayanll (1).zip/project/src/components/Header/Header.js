import { Logo } from '../Logo/Logo.js';
import { Navigation } from '../Navigation/Navigation.js';

export function Header() {
  return `
    <header class="header">
      ${Logo()}
      ${Navigation()}
    </header>
  `;
}