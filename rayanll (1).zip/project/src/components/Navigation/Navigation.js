import { ROUTES } from '../../constants/routes.js';

export function Navigation() {
  return `
    <nav class="nav">
      <a href="${ROUTES.HOME}" class="nav-link">Home</a>
      <a href="${ROUTES.CATEGORIES}" class="nav-link">Categories</a>
      <a href="${ROUTES.PRESCRIPTIONS}" class="nav-link">Prescriptions</a>
      <a href="${ROUTES.CONTACT}" class="nav-link">Contact</a>
    </nav>
  `;
}