export function Header() {
  return `
    <header class="header">
      <div class="logo">
        <img src="https://via.placeholder.com/50" alt="Rayan Pharmacy Logo">
        <h1>Rayan Pharmacy</h1>
      </div>
      <nav class="nav">
        <a href="#" class="nav-link">Home</a>
        <a href="#" class="nav-link">Categories</a>
        <a href="#" class="nav-link">Prescriptions</a>
        <a href="#" class="nav-link">Contact</a>
      </nav>
    </header>
  `;
}