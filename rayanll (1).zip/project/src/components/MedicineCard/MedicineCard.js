import { Button } from '../Button/Button.js';

export function MedicineCard({ name, description, image, category }) {
  return `
    <div class="card">
      <div class="card-badge">${category}</div>
      <img src="${image}" alt="${name}" class="card-image">
      <div class="card-content">
        <h3 class="card-title">${name}</h3>
        <p class="card-description">${description}</p>
        ${Button({ 
          text: 'Taste', 
          onClick: `handleMedicineTaste('${name}')`,
          className: 'card-button'
        })}
      </div>
    </div>
  `;
}