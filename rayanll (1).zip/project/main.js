import './style.css';
import { medicines } from './src/data/medicines.js';
import { MedicineCard } from './src/components/MedicineCard/MedicineCard.js';
import { Header } from './src/components/Header/Header.js';
import { handleMedicineTaste } from './src/utils/eventHandlers.js';

// Make event handler available globally
window.handleMedicineTaste = handleMedicineTaste;

document.querySelector('#app').innerHTML = `
  ${Header()}
  <main class="container">
    ${medicines.map(medicine => MedicineCard(medicine)).join('')}
  </main>
`;